package net.singular.singularsampleapp;

public interface Constants {
    String API_KEY = "<ENTER API KEY>";
    String SECRET = "<ENTER SECRET>";

    String DEEPLINK_KEY = "deeplink";
    String PASSTHROUGH_KEY = "passthrough";
    String IS_DEFERRED_KEY = "isDeferred";
}
